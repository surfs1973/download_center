# script.module.xbmcext

XBMCExt extends utilities, dialogs, and various control widgets.